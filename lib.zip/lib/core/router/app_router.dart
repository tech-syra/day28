import 'package:go_router/go_router.dart';

import '../../features/cart/presentation/pages/cart_screen.dart';
import '../../features/products/data/models/product.dart';
import '../../features/products/presentation/pages/product_detail_page.dart';
import '../../features/products/presentation/pages/product_list_page.dart';

final appRouter = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) {
        return const ProductListPage();
      },
    ),
    GoRoute(
      path: '/product',
      builder: (context, state) {
        final product = state.extra as Product;

        return ProductDetailPage(
          product: product,
        );
      },
    ),
    GoRoute(
      path: '/cart',
      builder: (context, state) {
        return const CartScreen();
      },
    ),
  ],
);

